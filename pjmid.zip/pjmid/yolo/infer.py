import argparse
import torch
import torch.nn as nn
import torch.optim as optim
import config
import numpy as np
import os
import pandas as pd
import random
from tqdm import tqdm
import time
import uuid
from PIL import ImageDraw, Image
from torchvision.transforms import Resize, ToTensor
from utils import (
    mean_average_precision,
    cells_to_bboxes,
    get_evaluation_bboxes,
    save_checkpoint,
    load_checkpoint,
    check_class_accuracy,
    get_loaders,
    plot_couple_examples
)

from base import Base as DatasetBase
from PIL import Image, ImageFile
from torch.utils.data import Dataset, DataLoader
from utils import (
    iou_width_height as iou,
    intersection_over_union,
    non_max_suppression as nms, # only for testing
    plot_image #only for testing
)
from main import *


if __name__ == "__main__":
    #main()
    parser = argparse.ArgumentParser()
    model = YOLOv3(num_classes=config.NUM_CLASSES).to(config.DEVICE)
    optimizer = optim.Adam(
        model.parameters(), lr=config.LEARNING_RATE, weight_decay=config.WEIGHT_DECAY
    )
    loss_fn = YoloLoss()
    scaler = torch.cuda.amp.GradScaler()
    scaler = torch.cuda.amp.GradScaler()
    load_checkpoint(config.CHECKPOINT_FILE, model, optimizer, config.LEARNING_RATE)

    parser.add_argument('-p', '--picture', type=str, required=True, help='Picture to infer')
    args = parser.parse_args()
    infer(model, args.picture)
        