# 神经网络和深度学习 期中项目

本报告主题为课程神经网络和深度学习课程的期中项目，小组成员有：蒋勉21210980040、裴晓阳21210980058

本项目repo地址为：[https://github.com/JuvenileMartian/neurNetMid]()

模型相关文件上传到百度云，地址为：

CNN: [https://pan.baidu.com/s/1Pwt5tB0jQUigww2DsdY6cQ?pwd=tm6b]()

YOLO: [https://pan.baidu.com/s/1Ejt46dEaG0HaqK_-PTB7DQ?pwd=kd8g]()

Faster R-CNN: [https://pan.baidu.com/s/12BWWXdEeODtfgAA-yPpEkw?pwd=2v60]()

## MISSION1

### 要求

#### 任务要求

使用CNN网络模型(自己设计或使用现有的CNN架构，如AlexNet，ResNet-18)作为baseline在CIFAR-100上训练并测试；对比cutmix, cutout, mixup三种方法以及baseline方法在CIFAR-100图像分类任务中的性能表现；对三张训练样本分别经过cutmix, cutout, mixup后进行可视化，一共show 9张图像。

#### 报告要求

详细的实验报告包括实验设置：

数据集介绍，训练测试集划分，网络结构，batch size，learning rate，优化器，iteration，epoch，loss function，评价指标，检测/分割结果可视化；
利用Tensorboard可视化训练和测试的loss曲线、测试mAP/Acc/mIoU 曲线。

### 数据集

数据集为CIFAR100数据集，本数据集共有100个类。每个类有600张大小为32 × 32 的彩色图像，其中500张作为训练集，100张作为测试集。对于每一张图像，它有fine_labels和coarse_labels两个标签，分别代表图像的细粒度和粗粒度标签，对应下图中的classes和superclass。也就是说，CIFAR100数据集是层次的。

![CIFAR-100介绍](https://img-blog.csdnimg.cn/20201101234230158.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzQ1NTg5NjU4,size_16,color_FFFFFF,t_70#pic_center)

### 神经网络模型

使用经典的Resnet-18模型作为Baseline。
原始Resnet-18的具体架构图为：
![resnet18](https://img-blog.csdnimg.cn/20210615172539557.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl80Mzk5OTY5MQ==,size_16,color_FFFFFF,t_70)
上图参考于[https://www.jianshu.com/p/085f4c8256f1](https://www.jianshu.com/p/085f4c8256f1)

在我们模型中图片的大小为32 × 32，所以将架构图中的224改为32，其它层维度做出相应的改变。

其中卷积层有17个，FC层1个，一共18个，上图中实线表示残差块中的通道数没有变化，虚线表示通道数变化，通道数变化后通过卷积调整一下通道数，然后将步长调整成2。

#### 参数/指标设置

网络中具体使用的参数以及训练模型的评价指标列表如下所示：

| 参数/指标     | 值                                                  |
| ------------- | --------------------------------------------------- |
| batch size    | 128                                                 |
| learning rate | 0.01                                                |
| 优化器        | mini-batch momentum-SGD，并采用L2正则化（权重衰减） |
| momentum      | 0.9                                                 |
| iteration     | 6260                                                |
| epoch         | 20                                                  |
| loss function | 交叉熵                                              |
| Acc           | TP平均值                                            |
| Precision     | TP / (TP + FP) if TP + FP != 0 else 0.              |
| mAP           | Precision类平均值                                   |
| IoU           | TP / (TP + FP + FN) if TP + FP +FN != 0 else 0.     |
| mIoU          | IoU类平均值                                         |

### 可视化

#### 训练样本图像可视化

![](image/readme/1652532345823.png)

#### 性能对比-Tensorboard可视化

在epoch=20时，分别训练 Baseline/Mixup/Cutout/Cutmix 四个模型。
平台为pytorch 1.11.0，笔记本电脑显卡为3060 6g显存。
将CIFAR100数据集放置在MISSION1子目录，运行以下代码即可训练模型

```
python main.py
```

或者运行形如以下代码在训练模型时选择相应参数。

```
python main.py ---method cutmix --epoch 20
```

运行时间：baseline 用时1140.49秒；cutout 用时1150.15秒；mixup 用时1153.17秒；cutmix 用时1151.64秒；一共用时4595.45秒。
在当前训练环境下，四个模型训练速度并无显著差异。

在训练以及测试模型时，保存使用不同方法训练和测试的loss数据以及测试中的mAP/Acc/mIoU等指标，调用Tensorboard进行可视化分析。便于报告将相关图像截图展示在下方。

##### Baseline/Mixup/Cutout/Cutmix train/val loss曲线

train loss曲线：
![loss](img\train_loss.png)
训练集中loss曲线的收敛由快到慢分别是：baseline、cutout、mixup、cutmix

val loss曲线：
![loss](img\val_loss.png)
测试集中loss曲线的收敛由快到慢分别是：baseline、cutmix、mixup、cutout

##### Baseline/Mixup/Cutout/Cutmix测试集指标

val_mAP:
![loss](img\mAP.png)
测试集中mAP由大到小分别是：cutmix、cutout、baseline、mixup

val_Acc:
![loss](img\Acc.png)
测试集中Acc由大到小分别是：baseline、cutmix、cutout、mixup

val_mIoU:
![loss](img\mIoU.png)
测试集中mAP由大到小分别是：baseline、cutmix、cutout、mixup

综合以上图片，可以认为模型训练速度依次是：baseline、cutmix、mixup、cutout；模型性能依次是：baseline、cutmix、cutout、mixup。

## MISSION 2

#### 任务要求

在VOC数据集上训练并测试目标检测模型Faster R-CNN和YOLO V3；在四张测试图像上可视化Faster R-CNN第一阶段的proposal box；
两个训练好后的模型分别可视化三张不在VOC数据集内，但是包含有VOC中类别物体的图像的检测结果（类别标签，得分，boundingbox），并进行对比，一共show六张图像。

### 数据集

数据集为VOC 2007数据集，本数据集共有20个类。ImageSets文件夹中的文件指定了训练集与测试集的划分。JPEGImage文件夹中包含数据集拥有的原始图像，每张图像尺寸补丁，对应着Annotations文件夹中的一个xml文件，其中注明了该图像中目标的分类与锚框。

### 神经网络模型

分别训练了以Resnet-101为Backbone的 Faster R-CNN 与 YOLO v3 模型。

Faster R-CNN的源代码来自项目 [https://github.com/potterhsu/easy-faster-rcnn.pytorch]()，调整了部分代码使之能在本机的pytorch 1.11 与 cuda 11.3环境中运行，并客制化了项目展示所需要的一些功能（如在推理中截获一阶段bbox等）。

YOLO v3 的源代码来自项目 [https://github.com/aladdinpersson/Machine-Learning-Collection/tree/master/ML/Pytorch/object_detection/YOLOv3]()，同样进行了本地化调整。

#### 参数/指标设置

网络中具体使用的参数以及训练模型的评价指标列表如下所示：

| 参数/指标     | YOLO v3                                         | Faster R-CNN                                           |
| ------------- | ----------------------------------------------- | ------------------------------------------------------ |
| batch size    | 16                                              | 2                                                      |
| learning rate | 3e-5                                            | 0.01                                                   |
| 优化器        | Adam                                            | SGD with MultiStepLR，在5万步与7万步处缩小lr至十分之一 |
| momentum      |                                                 | 0.9                                                    |
| iteration     |                                                 | 200000                                                 |
| epoch         | 300                                             |                                                        |
| loss function | 多项加总                                        | 多项加总                                               |
| Acc           | TP平均值                                        |                                                        |
| Precision     | TP / (TP + FP) if TP + FP != 0 else 0.          |                                                        |
| mAP           | Precision类平均值                               |                                                        |
| IoU           | TP / (TP + FP + FN) if TP + FP +FN != 0 else 0. |                                                        |
| mIoU          | IoU类平均值                                     |                                                        |

### 可视化

#### 训练与部署

按照如上参数训练。
平台为pytorch 1.11.0，CUDA 1.13，使用 GPU 为 3080 Ti 12GB

**Train:** 将VOCdevkit置于 FRcnn/data/ 目录中，以 FRcnn/ 为工作目录输入以下代码，即可训练 Faster R-CNN 模型：

```
python train.py -s=voc2007 -b=resnet101
```

**Infer:** 指定模型路径、输入图像路径与输出路径，以 FRcnn/ 为工作目录输入以下代码，即可利用上一步所得的 Faster R-CNN 模型对图像进行推理：

```
python infer.py -s=voc2007 -b=resnet101 -c=./frcnn_final.pth ./infer/input/p1.jpg ./infer/output/p1.jpg
```

**Train:** 将VOCdevkit置于 yolo/ 目录中，以 yolo/ 为工作目录输入以下代码，即可训练 YOLO v3 模型：

```
python main.py
```

**Infer:** 将图像文件置于 yolo/infer/input 目录中，以 yolo/ 为工作目录输入以下代码，即可利用上一步所得的 YOLO v3 模型对图像进行推理，结果将保存在 yolo/infer/output 中：

```
python infer.py -p picture.jpg
```

两模型有关速度与开销的指标列举如下：

| 性能指标     | YOLO v3 | Faster R-CNN |
| ------------ | ------- | ------------ |
| 推理所需显存 | 5.0GB   | 1.6GB        |
| 推理FPS      | 79.88   | 20.53        |

#### Faster R-CNN 可视化

**loss曲线**

![](image/readme/1652531698958.png)

**性能**

![](image/readme/1652529220414.png)

**Proposal Box展示**

随机选中VOC2007数据集内4张原始图片，在模型推理时截获一阶段Proposal Box进行可视化展示，效果如下：

![](image/readme/1652530882024.png)

#### YOLO v3 可视化

**Tensorboard记录**

![img](image/readme/1652529900527.png)

#### 模型对比

选取三张不在VOC数据集内，但是包含有VOC中类别物体的图像用两个模型进行检测，展示对比的情况：

![](image/readme/1652529999312.png)

Faster R-CNN检测图1的结果细节：

![](image/readme/1652530311450.png)

我们分别选择了有大量目标的图1，含有飞机、人类、车辆的图2，含有猫、狗的图3.

Faster R-CNN成功地在图1中检索到了4个目标，并且进行了正确的分类；正确地识别了图2中的三个目标，但在飞机处额外出现了一个假正例；正确地以极高的置信度识别了图3的两个目标。

Yolo v3在图1中正确地定位了1个目标，但进行了错误的分类；在图2中正确地识别了人和汽车，然而未能检测出飞机，且在汽车出出现了一个假正例；检测到了图3的两个目标，但未能正确归类，且出现了大量假正例。
