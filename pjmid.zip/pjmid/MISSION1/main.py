import os
import time
import argparse
import torch
from tqdm import tqdm
from torch import nn
import torch.nn.functional as F
from torchvision import transforms, datasets
import torchvision.models as models
import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader, TensorDataset
import os
from torch.utils.tensorboard import SummaryWriter



os.chdir('./')
SEED = 1234
beta = 0.3
cutmix_prob = 0.8

device = 'cpu'
if torch.cuda.is_available():
    device = 'cuda'

parser = argparse.ArgumentParser(description='Cutmix PyTorch CIFAR-10, CIFAR-100 and ImageNet-1k Training')
parser.add_argument('--net_type', default='pyramidnet', type=str,
                    help='networktype: resnet, and pyamidnet')
parser.add_argument('-j', '--workers', default=4, type=int, metavar='N',
                    help='number of data loading workers (default: 4)')
parser.add_argument('--epochs', default=5, type=int, metavar='N',
                    help='number of total epochs to run')
parser.add_argument('-b', '--batch_size', default=128, type=int,
                    metavar='N', help='mini-batch size (default: 256)')
parser.add_argument('--lr', '--learning-rate', default=0.1, type=float,
                    metavar='LR', help='initial learning rate')
parser.add_argument('--momentum', default=0.9, type=float, metavar='M',
                    help='momentum')
parser.add_argument('--weight-decay', '--wd', default=1e-4, type=float,
                    metavar='W', help='weight decay (default: 1e-4)')
parser.add_argument('--print-freq', '-p', default=1, type=int,
                    metavar='N', help='print frequency (default: 10)')
parser.add_argument('--depth', default=32, type=int,
                    help='depth of the network (default: 32)')
parser.add_argument('--no-bottleneck', dest='bottleneck', action='store_false',
                    help='to use basicblock for CIFAR datasets (default: bottleneck)')
parser.add_argument('--dataset', dest='dataset', default='imagenet', type=str,
                    help='dataset (options: cifar10, cifar100, and imagenet)')
parser.add_argument('--no-verbose', dest='verbose', action='store_false',
                    help='to print the status at every iteration')
parser.add_argument('--alpha', default=300, type=float,
                    help='number of new channel increases per depth (default: 300)')
parser.add_argument('--expname', default='TEST', type=str,
                    help='name of experiment')
parser.add_argument('--beta', default=0, type=float,
                    help='hyperparameter beta')
parser.add_argument('--cutmix_prob', default=0, type=float,
                    help='cutmix probability')
parser.add_argument('--method', default='baseline', type=str,
                    help='method')
parser.set_defaults(bottleneck=True)
parser.set_defaults(verbose=True)
args = parser.parse_args()
def CIFAR100_preload(device='cuda'):
    # 直接把数据塞到显存里，适用于显存很多的情况
    transform = transforms.Compose([transforms.ToTensor()])#,transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    test_set = datasets.CIFAR100('./CIFAR100', download=True, train=False, transform=transform)
    X_data = []
    for x in test_set.data:
        X_data.append(test_set.transform(x))
    X_data = torch.stack(X_data).to(device)
    targets_array = torch.LongTensor(test_set.targets).to(device)
    test_set = TensorDataset(X_data, targets_array)

    train_set = datasets.CIFAR100('./CIFAR100', download=True, train=True, transform=transform)
    X_data = []
    for x in train_set.data:
        X_data.append(train_set.transform(x))
    X_data = torch.stack(X_data).to(device)
    targets_array = torch.LongTensor(train_set.targets).to(device)
    train_set = TensorDataset(X_data, targets_array)
    return train_set, test_set

def CIFAR100(device):
    transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    train_set = datasets.CIFAR100('./CIFAR100', download=True, train=True, transform=transform)
    test_set = datasets.CIFAR100('./CIFAR100', download=True, train=False, transform=transform)    
    return train_set, test_set

#使用混淆矩阵计算指标
class ConfusionMatrix(object):


    def __init__(self, num_classes: int, labels: list):
        self.matrix = np.zeros((num_classes, num_classes))#初始化混淆矩阵，元素都为0
        self.num_classes = num_classes#类别数量，本例数据集类别为5
        self.labels = labels#类别标签

    def update(self, preds, labels):
        for p, t in zip(preds, labels):#pred为预测结果，labels为真实标签
            self.matrix[p, t] += 1#根据预测结果和真实标签的值统计数量，在混淆矩阵相应位置+1

    def summary(self):#计算指标函数
        sum_TP = 0
        sum_AP = 0
        sum_IoU = 0
        n = np.sum(self.matrix)
        for i in range(self.num_classes):#精确度、召回率、特异度的计算
            TP = self.matrix[i, i]
            FP = np.sum(self.matrix[i, :]) - TP
            FN = np.sum(self.matrix[:, i]) - TP
            TN = np.sum(self.matrix) - TP - FP - FN
            sum_TP += TP
            Precision = TP / (TP + FP) if TP + FP != 0 else 0.
            sum_AP += Precision
            IoU = TP / (TP + FP + FN) if TP + FP +FN != 0 else 0.
            sum_IoU += IoU
            #Recall = TP / (TP + FN) if TP + FN != 0 else 0.#每一类准确度
            #Specificity = TN / (TN + FP) if TN + FP != 0 else 0.
        Acc = sum_TP / n#总体准确率
        mAP = sum_AP / self.num_classes
        mIoU = sum_IoU / self.num_classes
        return mAP, Acc, mIoU

    
class AverageCalculator():
    def __init__(self):
        self.reset() 
    
    def reset(self):
        self.count = 0
        self.sum = 0
        self.avg = 0
    
    def update(self, val, n=1):
        assert(n > 0)
        self.sum += val * n 
        self.count += n
        self.avg = self.sum / float(self.count)

def accuracy(yhat, labels):
    _, indices = yhat.max(1)
    return (indices == labels).sum().data.item() / float(len(labels))


def train_epoch(model, optimizer, train_loader, loss_fn, method='baseline',recorder=None,
                                      beta=0.3,prob=-1.0,n_holes=1,length=16,picshow=False):
    if method not in ['baseline','mixup','cutout','cutmix']:
        print('method error!')
    if prob<0 or prob>1:
        problist={'baseline':1.0,'mixup':1.0,'cutout':1.0,'cutmix':0.8}
        prob=problist[method]
    
    model.train()
    loss_rec = AverageCalculator()
    acc = AverageCalculator()

    for images, labels in tqdm(train_loader):
        
        input=images.to(device)
        target=labels.to(device)
        target_a = target
        target_b = target
        lam=1.0

        r=np.random.rand(1)
        if method!='baseline' and (beta>0 and r<prob):
            if method=='cutout':
                _, _, h, w = input.shape
                h = input.shape[2]
                w = input.shape[3]
                lam = 1 - (length ** 2 / (h * w))
                for _ in range(n_holes):
                    bbx1, bby1, bbx2, bby2 = rand_bbox(input.size(), lam)
                    input[:, :, bbx1:bbx2, bby1:bby2] = 0.
            else:
                lam = np.random.beta(beta, beta)
                rand_index = torch.randperm(input.size()[0]).to(device)
                target_a = target
                target_b = target[rand_index]
                bbx1, bby1, bbx2, bby2 = rand_bbox(input.size(), lam)
                if method=='cutmix':
                    input[:, :, bbx1:bbx2, bby1:bby2] = input[rand_index, :, bbx1:bbx2, bby1:bby2]
                    lam = 1 - ((bbx2 - bbx1) * (bby2 - bby1) / (input.size()[-1] * input.size()[-2]))
                else:#method=mixup
                    input = lam * input + (1 - lam) * input[rand_index, :, :]
        output = model(input)
        loss = loss_fn(output, target_a) * lam + loss_fn(output, target_b) * (1. - lam)
        acc_iter = accuracy(output, target_a) * lam + accuracy(output, target_b) * (1. - lam)
        # optimization 
        optimizer.zero_grad()
        loss.backward()    
        optimizer.step()
        # logging 
        loss_rec.update(loss.data.item())
        acc.update(acc_iter)
 
    return loss_rec.avg, acc.avg


def validate_epoch(model, val_loader, loss_fn):
    """One epoch of validation
    """
    model.eval()
    loss = AverageCalculator()
    acc = AverageCalculator()

    CM = ConfusionMatrix(100,list(range(100)))
    for images, labels in val_loader:
        images = images.to(device)
        yhat = model(images)
        labels = labels.to(device)

        # logging 
        loss_iter = loss_fn(yhat, labels)
        acc_iter = accuracy(yhat, labels)
        loss.update(loss_iter.data.item())
        acc.update(acc_iter)

        _, indices = yhat.max(1)
        indices = indices.tolist()
        labels = labels.tolist()
        CM.update(indices,labels)

    mAP=CM.summary()[0]
    mIoU = CM.summary()[2]

    return loss.avg, acc.avg, mAP, mIoU

def iview(idx):
    plt.imshow(np.array(train_set[idx][0].to('cpu')).transpose(1,2,0))

def rand_bbox(size, lam):
    W = size[2]
    H = size[3]
    cut_rat = np.sqrt(1. - lam)
    cut_w = int(W * cut_rat)
    cut_h = int(H * cut_rat)

    # uniform
    cx = np.random.randint(W)
    cy = np.random.randint(H)

    bbx1 = np.clip(cx - cut_w // 2, 0, W)
    bby1 = np.clip(cy - cut_h // 2, 0, H)
    bbx2 = np.clip(cx + cut_w // 2, 0, W)
    bby2 = np.clip(cy + cut_h // 2, 0, H)

    return bbx1, bby1, bbx2, bby2

class AlexNet(nn.Module):
    def __init__(self):
        super(AlexNet,self).__init__()
        
        # 3通道 转 96通道
        self.conv1=nn.Conv2d(3,96,kernel_size=3,stride=1)   #32->30
        self.bn1=nn.BatchNorm2d(96)                         #30->30
        self.pool1=nn.MaxPool2d(kernel_size=3,stride=2)     #30->14
        
        # 96通道 转 256通道
        self.conv2=nn.Conv2d(96,256,kernel_size=3,stride=1) #14->12     
        self.bn2=nn.BatchNorm2d(256)                        #12->12 
        self.pool2=nn.MaxPool2d(kernel_size=3,stride=2)     #12->5
                
        self.conv3=nn.Conv2d(256,384,kernel_size=3,padding=1,stride=1)
        self.conv4=nn.Conv2d(384,384,kernel_size=3,padding=1,stride=1)        
        self.conv5=nn.Conv2d(384,256,kernel_size=3,padding=1,stride=1)
        self.pool3=nn.MaxPool2d(kernel_size=3,stride=2)     #5->2      
        
        self.linear1=nn.Linear(1024,2048)      # 256*2*2 = 1024
        self.dropout1=nn.Dropout(0.5)
                
        self.linear2=nn.Linear(2048,2048) 
        self.dropout2=nn.Dropout(0.5)
                
        self.linear3=nn.Linear(2048,100)
        
    def forward(self,x):
        
        out=self.conv1(x)
        out=self.bn1(out)
        out=F.relu(out)
        out=self.pool1(out)        
        
        out=self.conv2(out)
        out=self.bn2(out)
        out=F.relu(out)
        out=self.pool2(out)
        
        out=F.relu(self.conv3(out))        
        out=F.relu(self.conv4(out))        
        out=F.relu(self.conv5(out))        
        out=self.pool3(out)
        
        out=out.reshape(-1,256*2*2)        
        out=F.relu(self.linear1(out))
        
        out=self.dropout1(out)        
        out=F.relu(self.linear2(out))        
        out=self.dropout2(out)
        
        out=self.linear3(out)
        
        return out

class ResBlock(nn.Module):
    def __init__(self, inchannel, outchannel, stride=1):
        super(ResBlock, self).__init__()
        #这里定义了残差块内连续的2个卷积层
        self.left = nn.Sequential(
            nn.Conv2d(inchannel, outchannel, kernel_size=3, stride=stride, padding=1, bias=False),
            nn.BatchNorm2d(outchannel),
            nn.ReLU(inplace=True),
            nn.Conv2d(outchannel, outchannel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(outchannel)
        )
        self.shortcut = nn.Sequential()
        if stride != 1 or inchannel != outchannel:
            #shortcut，这里为了跟2个卷积层的结果结构一致，要做处理
            self.shortcut = nn.Sequential(
                nn.Conv2d(inchannel, outchannel, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(outchannel)
            )
            
    def forward(self, x):
        out = self.left(x)
        #将2个卷积层的输出跟处理过的x相加，实现ResNet的基本结构
        out = out + self.shortcut(x)
        out = F.relu(out)
        
        return out

class ResNet(nn.Module):
    def __init__(self, ResBlock, num_classes=100):
        super(ResNet, self).__init__()
        self.inchannel = 64
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU()
        )
        self.layer1 = self.make_layer(ResBlock, 64, 2, stride=1)
        self.layer2 = self.make_layer(ResBlock, 128, 2, stride=2)
        self.layer3 = self.make_layer(ResBlock, 256, 2, stride=2)        
        self.layer4 = self.make_layer(ResBlock, 512, 2, stride=2)        
        self.fc = nn.Linear(512, num_classes)
    #这个函数主要是用来，重复同一个残差块    
    def make_layer(self, block, channels, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.inchannel, channels, stride))
            self.inchannel = channels
        return nn.Sequential(*layers)
    
    def forward(self, x):
        #在这里，整个ResNet18的结构就很清晰了
        out = self.conv1(x)
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = F.avg_pool2d(out, 4)
        out = out.view(out.size(0), -1)
        out = self.fc(out)
        return out

if __name__ == '__main__':


    #准备数据集
    train_data, test_set = CIFAR100(device)
    #train_data, test_set = CIFAR2()     
    N = len(train_data)
    train_set, valid_set = torch.utils.data.random_split(train_data, [int(N*0.8), N-int(N*0.8)], torch.Generator().manual_seed(SEED))
    train_loader = DataLoader(train_set, batch_size=128, shuffle=True)
   
    val_loader = DataLoader(valid_set, batch_size=128, shuffle=True)
    test_loader = DataLoader(test_set, batch_size=128, shuffle=False)                               
    
    #超参数设置
    n_epoch = args.epochs
    
    #x = train_set[:64][0]
    #x0 = x[0:1]
    
   
 
    alex = AlexNet().to(device) 
    resnet = ResNet(ResBlock).to(device)
    #resnet.fc = nn.Linear(512, 100).to(device)
    resnet152 = models.resnet152().to(device)
    resnet152.fc = nn.Linear(2048, 100).to(device)
    
    #选择模型
    model = resnet
    model_name = 'resnet'
    method = args.method
    print('Use the model of %s with the method of %s' %(model_name,method))
    loss = nn.CrossEntropyLoss()  # 损失函数为交叉熵，多用于多分类问题
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9, weight_decay=0.0005) # 优化方式为mini-batch momentum-SGD，并采用L2正则化（权重衰减）

    #模型保存路径
    save_weights='./weights/'+method
    if os.path.exists(save_weights) is False:
        os.makedirs(save_weights)
    save_tb='./tensorboards/'+method
    if os.path.exists(save_tb) is False:
        os.makedirs(save_tb)

    a = resnet.layer2[0].shortcut[0]

    for epoch in range(n_epoch):
        t0 = time.time()


        # training
        """'train_epoch'函数实现数据增强的三种方法，用'method'进行指定，默认为'baseline'
        此外还有mixup,cutout,cutmix三种方式。
        在选定为cutout时，有参数n_holes=1,length=16进行调整；
        在选定cutmix时，有参数beta=0.3进行调整
        三种方法中的增强概率分别设为了1.0,1.0,0.8，若有需要可以在原函数中进行修改"""
        model.train()
        train_loss, train_acc = train_epoch(model, optimizer, train_loader, loss, method, recorder=None)
         
        # validation 
        model.eval()
        val_loss, val_acc, val_mAP, val_mIoU= validate_epoch(model, val_loader, loss)
        
        #利用Tensorboard可视化训练、测试的loss曲线、测试mAP/Acc/mIoU 曲线

        # myWriter.add_scalar('val_mIoU', val_mIoU, epoch) 
        myWriter = SummaryWriter(save_tb)
        myWriter.add_scalars('loss', {'train_loss':train_loss,'val_loss':val_loss}, epoch)
        myWriter.add_scalars('val', {'val_mAP':val_mAP,'val_Acc':val_acc,'val_mIoU':val_mIoU}, epoch) 
        

        fmt_str = "method:{}, epoch: {}, n_epoch: {}, train loss: {:.4f}, train acc: {:.4f}, val loss: {:.4f}, val acc: {:.4f}, val mAP: {:.4f}, val mIoU: {:.4f}, time: {:.2f}"
        savelog = fmt_str.format(method, epoch, n_epoch, train_loss, train_acc, val_loss, val_acc,val_mAP,val_mIoU, time.time() - t0)
        print(savelog)
        
        # 将训练指标存入文档
        with open('trainprocess'+method+'.txt', 'a') as f:
            f.write(savelog)
            f.write('\n')

        # 保存权重
        torch.save(model.state_dict(), save_weights+"/{}_model-{}.pth".format(method,epoch))
