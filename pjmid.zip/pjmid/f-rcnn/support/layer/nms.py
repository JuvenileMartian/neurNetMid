# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.

from support import _C

nms = _C.nms
